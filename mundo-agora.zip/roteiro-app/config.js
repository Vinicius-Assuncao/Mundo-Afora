// Configuração do projeto. Edite aqui.
const CONFIG = {
  APP_NAME: 'Mundo Agora',
  // Chave gratuita do OpenRouteService (openrouteservice.org).
  // Restrinja a chave ao seu domínio no painel deles.
  ORS_KEY: 'COLE_SUA_CHAVE_AQUI',
};
